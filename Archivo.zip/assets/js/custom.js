function rnd(frN, toN) {
    var rN = Math.floor(Math.random() * (toN + 1 - frN)) + frN;
    return rN;
}

function unilenS(aS, ul, fc, p) {
    var rS = "" + aS;
    ul *= 1.0;
    if (fc == "" || fc == null) { fc = "0"; }
    if (p == "" || p == null) { p = 0; }
    var rL = rS.length;
    if (rL < ul) {
        for (var i = 1; i <= ul - rL; i++) {
            if (p == 0) { rS = "" + fc + rS; } else { rS += "" + fc; }
        }
    }
    return rS;
}


function init() {
    undefined = "undefined";
    mkCClist();
}



// Función que permite generar tarjetas
function chkCard(cdi) {

    cdi += "";

    if (c[1] == undefined || c[1] == null || c[1] == "") { mkCClist(); }

    var ccn = 0;
    var cn = "Desconocido"
    var cf = sbtString(cdi, " -/abcdefghijklmnopqrstuvwyzABCDEFGHIJLMNOPQRSTUVWYZ");


    if (leftS(cf, 1) == "4") { cf = leftS(cf, 8); }

    for (var i = 1; i <= tw; i++) {
        var cct = sbtString(c[i], " -/abcdefghijklmnopqrstuvwyzABCDEFGHIJLMNOPQRSTUVWYZ");

        if (leftS(cf, 1) == "4") { cct = leftS(cct, 8); }

        var ccc = cmpPattern(cf, cct);

        if (ccc) { ccn = i; break; }
    }

    if (ccn > 0) { cn = cd[i]; }

    return cn;
}

function chkLCD(cf) {
    var r = false;
    cf += "";
    var bl = isdiv(cf.length, 2);
    var ctd = 0;

    for (var i = 1; i <= cf.length; i++) {
        var cdg = midS(cf, i, 1);
        if (isdiv(i, 2) != bl) {
            cdg *= 2;
            if (cdg > 9) { cdg -= 9; }
        }

        ctd += cdg * 1.0;
    }

    if (isdiv(ctd, 10)) { r = true; }

    return r;
}

function prcso() {
    var separador = document.getElementById('ccnsp').value;
    var formato = document.getElementById('formato').value;
    var separador2, separadorfecha;
    var p1 = document.getElementById('BINNUMBER').value;

    if (formato == 1) {
        separador2 = "|";
        separadorfecha = "|";
    } else {
        separador2 = ", ";
        separadorfecha = "/";
    }

    tr = 1000;
    document.getElementById('cc_generated').value = "";

    var tarjetas = document.getElementById('ccghm').value;

    if (tarjetas < 1) { tarjetas = 1; } else if (tarjetas > 1000) { tarjetas = 1000; }
    document.getElementById('ccghm').value = tarjetas;

    if (p1 != "" && p1 != null) {

        var out = '';

        for (var k = 1; k <= tarjetas; k++) {
            var year = document.getElementById('yearfixed').value;
            var mes = document.getElementById('datefixed').value;

            if (p1 == '') { p = c[Math.floor(Math.random() * (mxcards + 1 - 2)) + 2]; } else { p = p1; }
            var cn = chkCard(p);

            for (var i = tr; i >= 1; i--) {
                var cdi = sbtStringSpRnd(p, "x", "0123456789");
                var cf = sbtString(cdi, " -/abcdefghijklmnopqrstuvwyzABCDEFGHIJLMNOPQRSTUVWYZ");

                var clcd = chkLCD(cf);
                var ccck = chkCCCksum(cf, cn);

                if (clcd && ccck) { break; }
            }

            if (clcd && ccck) {
                var cn = "";
                // document.getElementById('banco').checked
                if (false) { cn = chkCard(cdi); }

                var cdif = "";
                for (var i = 1; i <= cdi.length; i++) {
                    var aS = midS(cdi, i, 1);
                    if (aS == " ") { aS = separador; }
                    cdif += aS;
                }
                var ccexp = '';

                if (document.getElementById('ccexpdat').checked) {
                    var dnow = new Date();
                    if (mes == 0) { mes = unilenS(rnd(1, 12), 2, '0', 0); }
                    if (year == 0) { year = (dnow.getFullYear() + Math.floor((Math.random() * 6) + 1)); }
                    ccexp = mes + separadorfecha + year;
                }

                var out = out += cdif;
                if (document.getElementById('ccexpdat').checked) { var out = out += separador2 + ccexp; }

                if (document.getElementById('ccv').checked) {
                    var ccv = document.getElementById('cvvfixed').value;

                    if (ccv == "") {
                        var ccv = ccv += aleatorio().toString() + aleatorio().toString() + aleatorio().toString();
                        if (p.substring(0, 1) == '3') {
                            var ccv = ccv += aleatorio().toString();
                        }
                    } else {
                        if (p.substring(0, 1) == '3' && ccv <= 999) {
                            var ccv = ccv += aleatorio().toString();
                        }
                    }

                    var out = out += separador2 + ccv;
                }

                if (cn != "") { var out = out += separador2 + cn; }

                var out = out + "\n"

            } else {

                var out = "Extrapolación Invalida";
            }
        }
        document.getElementById('cc_generated').value = out;

    } else {
        //toastr.clear();
        //toastr.options.positionClass = 'toast-bottom-full-width';
        //toastr.warning('Ingresa extrapolación', 'Aviso:');
        //$('#BINNUMBER').trigger('click');
        alert('Ingresa extrapolación');
    }
}

function aleatorio() {
    var aleatorio = Math.floor((Math.random() * 10));
    return aleatorio;
}

function chgccp() {
    mkCClist();
    for (var j = 0; j <= tw - 1; j++) {
        if (document.console.ccpp.options[j].selected) { break; }
    }

    document.console.BINNUMBER.value = c[j + 1];
}




function chkCCCksum(cf, cn) {
    var r = false;
    var w = "21";
    var ml = "";
    var j = 1;

    for (var i = 1; i <= cf.length - 1; i++) {
        var m = midS(cf, i, 1) * midS(w, j, 1);
        m = sumDigits(m);
        ml += "" + m;
        j++;

        if (j > w.length) { j = 1; }
    }

    var ml2 = sumDigits(ml, -1);
    var ml1 = (sumDigits(ml2, -1) * 10 - ml2) % 10;

    if (ml1 == rightS(cf, 1)) { r = true; }

    return r;
}



function mkCClist() {
    tw = 2;
    c = new makeArray(tw);
    cd = new makeArray(tw);
    var i = 1;
    c[i] = "";
    cd[i] = "BIN";
    i++;
    c[i] = "4246 8990 1584 xxxx";
    cd[i] = "Cinepolis ejemplo mas grande para extrapolar";
    i++;
    mxcards = i - 1;

}


function leftS(aS, n) {
    aS += "";
    var rS = "";
    if (n >= 1) {
        rS = aS.substring(0, n);
    }
    return rS;
}

function rightS(aS, n) {
    aS += "";
    var rS = "";
    if (n >= 1) {
        rS = aS.substring(aS.length - n, aS.length);
    }
    return rS;
}

function midS(aS, n, n2) {
    aS += "";
    var rS = "";
    if (n2 == null || n2 == "") { n2 = aS.length; }
    n *= 1;
    n2 *= 1;
    if (n < 0) { n++; }
    rS = aS.substring(n - 1, n - 1 + n2);
    return rS;
}

function linstr(aS, bS) {
    aS += "";
    bS += "";
    var r = false;
    if (leftS(aS, bS.length) == bS) { r = true; }
    return r;
}

function sbtString(s1, s2) {
    var ous = "";
    s1 += "";
    s2 += "";
    for (var i = 1; i <= s1.length; i++) {
        var c1 = s1.substring(i - 1, i);
        var c2 = s2.indexOf(c1);
        if (c2 == -1) { ous += c1; }
    }
    return ous;
}

function sbtStringSpRnd(s1, s2, bS) {
    if (bS == null || bS == "") { bS = "0123456789"; }
    var ous = "";
    bS += "";
    for (var i = 1; i <= s1.length; i++) {
        var c1 = s1.substring(i - 1, i);
        var c2 = s2.indexOf(c1);
        if (c2 == -1) { ous += c1; } else { ous += midS(bS, Math.floor(Math.random() * (bS.length - 1)) + 1, 1); }
    }
    return ous;
}

function cmpPattern(a, p, x) {
    if (x == "" || x == null) { x = "x"; }
    x = "" + x.substring(0, 1);
    a += "";
    p += "";
    r = false;
    mc = 0;
    if (a.length == p.length) {
        for (var i = 1; i <= a.length; i++) {
            a1 = midS(a, i, 1);
            p1 = midS(p, i, 1);
            if (a1 == p1 || p1 == x) { mc++; }
        }
    }
    if (mc == a.length) { r = true; }
    return r;
}

function isdiv(a, b) {
    if (b == null) { b = 2; }
    a *= 1.0;
    b *= 1.0;
    var r = false;
    if (a / b == Math.floor(a / b)) { r = true; }
    return r;
}

function sumDigits(n, m) {
    if (m == 0 || m == null) { m = 1; }
    n += "";
    if (m > 0) {
        while (n.length > m) {
            var r = 0;
            for (var i = 1; i <= n.length; i++) {
                r += 1.0 * midS(n, i, 1);
            }
            n = "" + r;
        }
    } else {
        for (var j = 1; j <= Math.abs(m); j++) {
            var r = 0;
            for (var i = 1; i <= n.length; i++) {
                r += 1.0 * midS(n, i, 1);
            }
            n = "" + r;
        }
    }
    r = n;
    return r;
}

function makeArray(n) {
    this.length = n;
    for (var i = 1; i <= n; i++) { this[i] = 0; }
    return this;
}


function ccchk() {


    var cdi = document.getElementById('validarcc').value;
    document.getElementById('txtverificacc').value = "";

    var digito = cdi.substring(0, 1);
    switch (digito) {
        case '4':
            document.getElementById("visa").className = "active";
            break;
        case '3':
            document.getElementById("american").className = "active";
            break;
        case '5':
            document.getElementById("mastercard").className = "active";
            break;

        default:
    }

    if (cdi != "" && cdi != null) {
        document.getElementById('txtverificacc').value = "Procesando...";
        var cf = sbtString(cdi, " -/abcdefghijklmnopqrstuvwyzABCDEFGHIJLMNOPQRSTUVWYZ|\#()[]{}£$%&=!?+*.,;:'");
        var cn = chkCard(cf);
        var clcd = chkLCD(cf);
        var clcdt = "Incorrecto";
        if (clcd) {
            clcdt = "Correcto";
        }
        var ccck = chkCCCksum(cf, cn);
        var ccckt = "Incorrecto";
        if (ccck) {
            ccckt = "Correcto";
        }
        var cjd = "Número de tarjeta invalido";
        if (clcd && ccck) {
            cjd = "El número de tarjeta es válido.";
        }
        var out = "";
        out += "Banco: " + cn + "\n";
        out += "Bin: " + ccckt + "\n";
        out += "Serie de tarjeta: " + clcdt + "\n";
        out += cjd;
        document.getElementById('txtverificacc').value = out;

    }

}

init();

$(document).ready(function() {
    $("#btng").click(function() {
        $("#divinformacion").load(document.getElementById('rt').value + "2", { xx: document.getElementById('BINNUMBER').value });
        prcso();
        $("#divinformacion").load(document.getElementById('rt').value, { xx: document.getElementById('BINNUMBER').value });

    });

})

function pais(pais) {
    document.getElementById('fL1oZnRCRtHz0a0Q14gh028329a1kMrY').value = pais;
}

function cargardato(extrapolacion) {
    document.getElementById('BINNUMBER').value = extrapolacion;
    $('#BINNUMBER').trigger('click');
    $('#btng').trigger('click');
}


